const { Pool } = require('pg');

const pool = new Pool({
  user: process.env.DB_USER,
  host: process.env.DB_HOST,
  database: process.env.DB_NAME,
  password: process.env.DB_PASSWORD,
  port: process.env.DB_PORT,
});

// User CRUD Operations
const createUserDB = async (userData) => {
  const { name, email, password, role = 'user' } = userData;
  const query = `
    INSERT INTO users (name, email, password, role, created_at)
    VALUES ($1, $2, $3, $4, NOW())
    RETURNING id, name, email, role, created_at
  `;
  const values = [name, email, password, role];
  
  try {
    const result = await pool.query(query, values);
    return result.rows[0];
  } catch (error) {
    throw new Error(`Error creating user: ${error.message}`);
  }
};

const getUserByEmailDB = async (email) => {
  const query = 'SELECT * FROM users WHERE email = $1';
  
  try {
    const result = await pool.query(query, [email]);
    return result.rows[0];
  } catch (error) {
    throw new Error(`Error getting user by email: ${error.message}`);
  }
};

const getUserByIdDB = async (id) => {
  const query = 'SELECT * FROM users WHERE id = $1';
  
  try {
    const result = await pool.query(query, [id]);
    return result.rows[0];
  } catch (error) {
    throw new Error(`Error getting user by id: ${error.message}`);
  }
};

const updateUserDB = async (id, userData) => {
  const { name, email, password, role } = userData;
  const updates = [];
  const values = [];
  let valueCount = 1;

  if (name) {
    updates.push(`name = $${valueCount}`);
    values.push(name);
    valueCount++;
  }
  if (email) {
    updates.push(`email = $${valueCount}`);
    values.push(email);
    valueCount++;
  }
  if (password) {
    updates.push(`password = $${valueCount}`);
    values.push(password);
    valueCount++;
  }
  if (role) {
    updates.push(`role = $${valueCount}`);
    values.push(role);
    valueCount++;
  }

  values.push(id);
  const query = `
    UPDATE users 
    SET ${updates.join(', ')}, updated_at = NOW()
    WHERE id = $${valueCount}
    RETURNING id, name, email, role, created_at, updated_at
  `;

  try {
    const result = await pool.query(query, values);
    return result.rows[0];
  } catch (error) {
    throw new Error(`Error updating user: ${error.message}`);
  }
};

const deleteUserDB = async (id) => {
  const query = 'DELETE FROM users WHERE id = $1 RETURNING *';
  
  try {
    const result = await pool.query(query, [id]);
    return result.rows[0];
  } catch (error) {
    throw new Error(`Error deleting user: ${error.message}`);
  }
};

module.exports = {
  pool,
  createUserDB,
  getUserByEmailDB,
  getUserByIdDB,
  updateUserDB,
  deleteUserDB
};