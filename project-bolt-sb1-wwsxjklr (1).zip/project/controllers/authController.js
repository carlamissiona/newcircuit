const jwt = require('jsonwebtoken');
const { getUserByEmail, createUser, verifyPassword } = require('../models/userModel');
const { jwtSecret, jwtExpiration, cookieName } = require('../config/auth');
// Import database functions for future use
// const { getUserByEmailDB, createUserDB } = require('../db');

// Show login page
const showLoginPage = (req, res) => {
  res.render('auth/login', { 
    title: 'Login',
    error: req.query.error || null,
    success: req.query.success || null
  });
};

// Show registration page
const showRegisterPage = (req, res) => {
  res.render('auth/register', { 
    title: 'Register',
    error: req.query.error || null 
  });
};

// Login user
const loginUser = async (req, res) => {
  const { email, password } = req.body;

  // Validate input
  if (!email || !password) {
    return res.render('auth/login', { 
      title: 'Login',
      error: 'Email and password are required',
      email
    });
  }

  /* 
  // Future implementation with database
  try {
    const user = await getUserByEmailDB(email);
    if (!user) {
      return res.render('auth/login', {
        title: 'Login',
        error: 'Invalid email or password',
        email
      });
    }
    // Continue with password verification and token generation
  } catch (error) {
    return res.render('auth/login', {
      title: 'Login',
      error: 'An error occurred during login',
      email
    });
  }
  */

  // Current implementation with in-memory storage
  const user = getUserByEmail(email);
  
  if (!user) {
    return res.render('auth/login', { 
      title: 'Login',
      error: 'Invalid email or password',
      email
    });
  }

  const isPasswordValid = await verifyPassword(password, user.password);
  
  if (!isPasswordValid) {
    return res.render('auth/login', { 
      title: 'Login',
      error: 'Invalid email or password',
      email
    });
  }

  const token = jwt.sign({ id: user.id }, jwtSecret, { expiresIn: jwtExpiration });
  
  res.cookie(cookieName, token, {
    httpOnly: true,
    maxAge: 24 * 60 * 60 * 1000,
    sameSite: 'strict'
  });

  res.redirect('/dashboard');
};

// Register user
const registerUser = async (req, res) => {
  const { name, email, password, confirmPassword } = req.body;

  if (!name || !email || !password) {
    return res.render('auth/register', {
      title: 'Register',
      error: 'All fields are required',
      name,
      email
    });
  }

  if (password !== confirmPassword) {
    return res.render('auth/register', {
      title: 'Register',
      error: 'Passwords do not match',
      name,
      email
    });
  }

  /* 
  // Future implementation with database
  try {
    const existingUser = await getUserByEmailDB(email);
    if (existingUser) {
      return res.render('auth/register', {
        title: 'Register',
        error: 'Email already in use',
        name
      });
    }

    await createUserDB({ name, email, password });
    res.redirect('/login?success=Registration successful! Please log in');
  } catch (error) {
    res.render('auth/register', {
      title: 'Register',
      error: 'Error creating user. Please try again.',
      name,
      email
    });
  }
  */

  // Current implementation with in-memory storage
  const existingUser = getUserByEmail(email);
  if (existingUser) {
    return res.render('auth/register', {
      title: 'Register',
      error: 'Email already in use',
      name
    });
  }

  try {
    await createUser({ name, email, password });
    res.redirect('/login?success=Registration successful! Please log in');
  } catch (error) {
    res.render('auth/register', {
      title: 'Register',
      error: 'Error creating user. Please try again.',
      name,
      email
    });
  }
};

// Logout user
const logoutUser = (req, res) => {
  res.clearCookie(cookieName);
  res.redirect('/login?success=You have been logged out successfully');
};

// Delete user (for future implementation)
const deleteUser = async (req, res) => {
  /* 
  // Future implementation with database
  try {
    const userId = req.params.id;
    await deleteUserDB(userId);
    res.redirect('/login?success=Account deleted successfully');
  } catch (error) {
    res.redirect('/profile?error=Error deleting account');
  }
  */
  res.status(501).json({ message: 'Not implemented' });
};

module.exports = {
  showLoginPage,
  showRegisterPage,
  loginUser,
  registerUser,
  logoutUser,
  deleteUser
};