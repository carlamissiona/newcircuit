const jwt = require('jsonwebtoken');
const { getUserByEmail, createUser, verifyPassword } = require('../models/userModel');
const { jwtSecret, jwtExpiration, cookieName } = require('../config/auth');

// Show login page
const showLoginPage = (req, res) => {
  res.render('auth/login', { 
    title: 'Login',
    error: req.query.error || null,
    success: req.query.success || null
  });
};

// Show registration page
const showRegisterPage = (req, res) => {
  res.render('auth/register', { 
    title: 'Register',
    error: req.query.error || null 
  });
};

// Login user
const loginUser = async (req, res) => {
  const { email, password } = req.body;

  // Validate input
  if (!email || !password) {
    return res.render('auth/login', { 
      title: 'Login',
      error: 'Email and password are required',
      email
    });
  }

  // Find user by email
  const user = getUserByEmail(email);
  
  // Check if user exists
  if (!user) {
    return res.render('auth/login', { 
      title: 'Login',
      error: 'Invalid email or password',
      email
    });
  }

  // Verify password
  const isPasswordValid = await verifyPassword(password, user.password);
  
  if (!isPasswordValid) {
    return res.render('auth/login', { 
      title: 'Login',
      error: 'Invalid email or password',
      email
    });
  }

  // Generate JWT token
  const token = jwt.sign({ id: user.id }, jwtSecret, { expiresIn: jwtExpiration });
  
  // Set token as cookie
  res.cookie(cookieName, token, {
    httpOnly: true,
    maxAge: 24 * 60 * 60 * 1000, // 24 hours
    sameSite: 'strict'
  });

  // Redirect to dashboard
  res.redirect('/dashboard');
};

// Register user
const registerUser = async (req, res) => {
  const { name, email, password, confirmPassword } = req.body;

  // Validate input
  if (!name || !email || !password) {
    return res.render('auth/register', {
      title: 'Register',
      error: 'All fields are required',
      name,
      email
    });
  }

  // Check if passwords match
  if (password !== confirmPassword) {
    return res.render('auth/register', {
      title: 'Register',
      error: 'Passwords do not match',
      name,
      email
    });
  }

  // Check if email already exists
  const existingUser = getUserByEmail(email);
  if (existingUser) {
    return res.render('auth/register', {
      title: 'Register',
      error: 'Email already in use',
      name
    });
  }

  try {
    // Create new user
    await createUser({ name, email, password });
    
    // Redirect to login page with success message
    res.redirect('/login?success=Registration successful! Please log in');
  } catch (error) {
    res.render('auth/register', {
      title: 'Register',
      error: 'Error creating user. Please try again.',
      name,
      email
    });
  }
};

// Logout user
const logoutUser = (req, res) => {
  res.clearCookie(cookieName);
  res.redirect('/login?success=You have been logged out successfully');
};

module.exports = {
  showLoginPage,
  showRegisterPage,
  loginUser,
  registerUser,
  logoutUser
};